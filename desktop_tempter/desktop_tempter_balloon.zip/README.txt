# ソフトウェアについて

【名    称】卓上誘技用バルーン
【種    別】バルーン
【制 作 者】タタキノフ
【動作確認】Windows 10 and Wine 7.9以降 / SSP 2.6.07以降
【配 布 元】https://tatakinov.github.io/
【連 絡 先】tatakinov_at_gmail.com
            https://twitter.com/tatakinov_ukgk


卓上誘技専用バルーンです。

